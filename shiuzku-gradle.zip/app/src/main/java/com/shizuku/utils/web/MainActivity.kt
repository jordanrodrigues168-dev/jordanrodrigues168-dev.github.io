package com.shizuku.utils.web

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : AppCompatActivity() {

    private lateinit var myWebView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        myWebView = WebView(this)
        
        val settings = myWebView.settings
        settings.javaScriptEnabled = true
        settings.allowFileAccess = true
        settings.domStorageEnabled = true
        // Important for loading local files correctly
        settings.allowContentAccess = true

        myWebView.webViewClient = WebViewClient()

        setContentView(myWebView)

        // Loading from the assets folder
        myWebView.loadUrl("file:///android_asset/main.html")
    }

    // This handles the back button so it doesn't close the app
    override fun onBackPressed() {
        if (myWebView.canGoBack()) {
            myWebView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
