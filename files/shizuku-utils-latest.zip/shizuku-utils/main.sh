#!/system/bin/sh
# --- Source the functions library ---
if [ -f functions.sh ]; then
    . ./functions.sh
else
    echo "[Error] functions.sh not found!"
    exit 1
fi

clear
header "$projectName"

info "Script Version: $version"
sleep 0.1
info "Debug Mode: $debugMode"
sleep 0.1
info "Developer: $developer"
sleep 0.1
info "Kernel Version: $kernelVersion"
sleep 0.1

# -- Connect to Shizuku Service --
header "Connection Process"
info "Connecting to Shizuku..."

if rish id 2&> /dev/null; then
    scs "Successfully connected to Shizuku!"
else
    err "Could not connect to Shizuku! Maybe it is not running."
fi

# -- Deploy all 3 binaries seamlessly --
deploy_binary "tweak-settings"
deploy_binary "debloat-tool"
deploy_binary "revert-settings"

# --- Execution Menu ---
while true; do
    header "Execution Menu"
    echo "1. tweak-settings  (Apply performance tweaks)"
    echo "2. debloat-tool    (Disable bloatware - Safe Mode)"
    echo "3. backup/restore  (Manage backups)"
    echo "4. revert-settings (Restore defaults)"
    echo "5. install apk (install any apk)"
    echo "6. Exit"
    echo
    read -p "[?] Choose a tool: " choice
    echo

    case $choice in
        1) rish "$execFolder/tweak-settings" ;;
        2) 
           # Take a snapshot before debloating
           take_debloat_snapshot
           rish "$execFolder/debloat-tool" 
           ;;
        3)
           echo "1. Take Package Snapshot"
           echo "2. Restore All Packages"
           read -p "[?] Choose action: " backup_choice
           case $backup_choice in
               1) take_debloat_snapshot ;;
               2) restore_all_packages ;;
           esac
           ;;
        4) rish "$execFolder/revert-settings" ;;
        5)  ;;
        6) exit 0 ;;
        *) 
    info "Maybe your using install.py"
    sh apk-installer.sh
    info "Please wait... executed apk-installer"
    sleep 1
    info "Now executing tweak-settings..."
    rish "$execFolder/tweak-settings"
    sleep 1
    ;;
    esac
done

info "Cleaning up..."
rish "rm -rf /data/local/tmp/tweak-settings"
rish "rm -rf /data/local/tmp/debloat-tool"
rish "rm -rf /data/local/tmp/revert-settings"