#!/system/bin/sh
# -- Source functions libary --
set -u
if [ -f "functions.sh" ]; then
. ./functions.sh
export RISH_APPLICATION_ID="$RISH_APPLICATION_ID"
else
echo "[Error] Cannot find the functions libary!"
echo "[Error] Exiting..."
exit 1
fi

# -- Disclaimer --

info "This script installs an APK file using Shizuku/rish"
sleep 0.2
info "Run only if you trust the source of the APK"
sleep 0.2
info "Use at your own risk"
sleep 0.2

# -- Check for app support --
info "CPU is $CPUNAME"
sleep 0.25

if [ "$CPUARCH" = "aarch64" ]; then
info "CPU supports $CPUARCH"
sleep 0.3
info "Most supported APK architecture"
sleep 0.25

else
err "CPU is old and does not support modern apps!"
fi

# -- Main Process --
header "APK Installer"

# -- Scan Directory --
info "Scanning directory..."
sleep 0.25

APK_PATH="files/apk/app-target.apk"

if [ -f "$APK_PATH" ]; then
    info "Found an apk: $APK_PATH"
    
    # Use -n to make read wait for input without a newline
    read -p "[input] Install it? [y/N]: " installChoice

    # -- User Authorization --
    case $installChoice in
        y|Y|yes|Yes)
        
            info "User permission granted"
            info "Trying to install APK via rish..."

            # -- Use rish to try to install the apk --
            if [ ! "$(rish 'pm install $APK_PATH > /dev/null')" ]; then
                err "Failed to install apk via rish!"
            fi
            scs "Successfully installed an apk!"
            ;;
        *)
            info "User has not granted permission or input invalid."
info "Or maybe they are using install.py"
            info "Exiting..."
            exit 1
            ;;
    esac
else
    err "No target apk found at: $APK_PATH"
    info "Please setup rish / Shizuku!"
fi