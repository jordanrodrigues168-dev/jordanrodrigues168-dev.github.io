#!/system/bin/sh
# --- Load configuration
if [ -f config.prop ]; then
  . ./config.prop
else
  echo "[Error] config.prop not found!"
  exit 1
fi

# -- Define Variables --

binFolder="files/bin"
execFolder="/data/local/tmp"
CPUARCH=$(uname -m)
CPUNAME=$(getprop ro.soc.model)
kernelVersion=$(uname -r | cut -d '-' -f 1,2)

# -- Setup directory for backups in current folder
BACKUP_DIR="./backups"
mkdir -p "$BACKUP_DIR"

# -- Define Functions --
info() {
  echo "[info] $*"
}

err() {
  echo "[Error] $*"
  echo "[Error] Exiting..."
  exit 1
}

scs() {
  echo "[Success] $*"
}

header() {
  local text="$1"
  local char="${2:-*}"
  local len=$((${#text} + 4))
  
  echo
  printf "%${len}s\n" | tr ' ' "$char"
  echo "$char $text $char"
  printf "%${len}s\n" | tr ' ' "$char"
  echo
}

rish() {
    if ! bash files/shizuku/rish/rish -c "$*"; then
        err "Shizuku command failed: $*"
    fi
}

take_debloat_snapshot() {
    local snapshot_file="$BACKUP_DIR/disabled_packages_$(date +%Y%m%d_%H%M%S).txt"
    info "Taking snapshot of disabled packages..."
    rish "pm list packages -d" | cut -d':' -f2 > "$snapshot_file"
    scs "Snapshot saved to $snapshot_file"
}

restore_all_packages() {
    info "Restoring all disabled packages..."
    for pkg in $(rish "pm list packages -d" | cut -d':' -f2); do
        info "Enabling $pkg..."
        rish "pm enable $pkg"
    done
    scs "All packages re-enabled."
}

# -- Easily deploy a binary
deploy_binary() {
    local bin_name="$1"
    local src="$binFolder/$bin_name"
    local dest="$execFolder/$bin_name"

    if [ ! -f "$src" ]; then
        err "Binary $bin_name not found in $binFolder!"
    fi
  
    if [ -f "$dest" ]; then
        rish rm "$dest"
    fi
    rish cp "$src" "$dest"
    rish chmod +x "$dest"
    info "Deployed $bin_name"
}
